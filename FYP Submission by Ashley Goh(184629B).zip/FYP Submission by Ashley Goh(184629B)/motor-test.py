from jetbot import Robot
import time
robot = Robot()

robot.forward()
robot.left_motor.value = 0.4
robot.right_motor.value = 0.3

time.sleep(5)
robot.left_motor.value = 0
robot.right_motor.value = 0
robot.set_motors(0.5, 0.5)

time.sleep(5)
robot.left_motor.value = 0
robot.right_motor.value = 0

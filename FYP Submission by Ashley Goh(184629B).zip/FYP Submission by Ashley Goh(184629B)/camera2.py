import cv2

GSTREAMER_PIPELINE = 'nvarguscamerasrc ! video/x-raw(memory:NVMM), width=3280, height=2464, format=(string)NV12, framerate=10/1 ! nvvidconv flip-method=0 ! video/x-raw, width=640, height=480, format=(string)BGRx ! videoconvert ! video/x-raw, format=(string)BGR ! appsink'

video_capture = cv2.VideoCapture(GSTREAMER_PIPELINE, cv2.CAP_GSTREAMER)
if video_capture.isOpened():
    cv2.namedWindow("Face Detection Window", cv2.WINDOW_AUTOSIZE)
    while True:
        return_key, image = video_capture.read()
        frame = cv2.resize(image, (300, 300))
        gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        
        cv2.imshow("Face Detection Window", frame)
        key = cv2.waitKey(30) & 0xff
        # Stop the program on the ESC key
        if key == 27:
           break
    video_capture.release()
    cv2.destroyAllWindows()
else:
    print("Cannot open Camera")

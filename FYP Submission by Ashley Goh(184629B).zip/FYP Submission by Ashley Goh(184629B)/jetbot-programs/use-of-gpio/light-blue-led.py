import RPi.GPIO as GPIO
import time

# Pin Definitions
LED3BLUE_pin = 23  # BOARD pin 12, BCM pin 18

def main():
    # Pin Setup:
    # Board pin-numbering scheme
    GPIO.setmode(GPIO.BCM)
    # Set pin to output mode, and set level is high
    GPIO.setup(LED3BLUE_pin, GPIO.OUT, initial=GPIO.HIGH)

    print("Starting demo now!")
    curr_value = GPIO.HIGH
    try:
        while True:
            #  Flip the output every 0.25 seconds
            time.sleep(0.25)
            print("Outputting {} to pin {}".format(curr_value, LED3BLUE_pin))
            GPIO.output(LED3BLUE_pin, curr_value)
            curr_value ^= GPIO.HIGH
    finally:
        GPIO.cleanup()

if __name__ == '__main__':
    main()


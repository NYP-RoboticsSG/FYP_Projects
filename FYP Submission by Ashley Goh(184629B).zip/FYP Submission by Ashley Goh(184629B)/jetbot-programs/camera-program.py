from jetbot import Camera

camera = Camera.instance(width=224, height=224)

import ipywidgets.widgets as widgets
image = widgets.Image(format='jpeg', width=224, height=224)
display(image)

from jetbot import bgr8_to_jpeg
import traitlets
camera_link = traitlets.dlink((camera, 'value'), (image, 'value'), transform=bgr8_to_jpeg)

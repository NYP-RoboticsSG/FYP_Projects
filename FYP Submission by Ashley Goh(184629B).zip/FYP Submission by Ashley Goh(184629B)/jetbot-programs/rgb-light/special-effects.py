from RGB_Lib import Programing_RGB
import time
RGB = Programing_RGB()

RGB.Set_WaterfallLight_RGB()
time.sleep(2)

RGB.Set_ChameleonLight_RGB()
time.sleep(2)

RGB.Set_BreathColor_RGB()
time.sleep(2)

RGB.Set_BreathSColor_RGB(0)
RGB.Set_BreathSSpeed_RGB(3)
RGB.Set_BreathSLight_RGB()
time.sleep(2)

RGB.OFF_ALL_RGB()

import time
import Adafruit_SSD1306
from PIL import Image
from PIL import ImageDraw
from PIL import ImageFont
from jetbot.utils.utils import get_ip_address
import subprocess

# 128x32 Display and hardwareI2C:
disp = Adafruit_SSD1306.SSD1306_128_32(rst=None, i2c_bus=0, gpio=1)#Set gpio to hack to 1 to avoid platform detection
# Initialization of library.
disp.begin()
# Clear display
disp.clear()
disp.display()
# Create a blank image for the drawing
# Make sure to create an image with a mode of '1' or a 1-bit color
width = disp.width
height = disp.height
image = Image.new('1', (width, height))
# Get the drawing object to be drawn on the image
draw = ImageDraw.Draw(image)
# Draw a black filled box to clear the image
draw.rectangle((0,0,width,height), outline=0, fill=0)
# Draw some shapes
# First,we need to define some constants to adjust the size of the shape
padding = -2
top = padding
bottom = height-padding
# Move from left to right to track the current x position of the drawing graph.
x = 0
# Load default font
font = ImageFont.load_default()

while True:

    #  Draw a black filled box to clear the image
    draw.rectangle((0,0,width,height), outline=0, fill=0)

    # From this link you can get the shell script for system monitoring: : 
    # https://unix.stackexchange.com/questions/119126/command-to-display-memory-usage-disk-usage-and-cpu-load
    cmd = "top -bn1 | grep load | awk '{printf \"CPU Load: %.2f\", $(NF-2)}'"
    CPU = subprocess.check_output(cmd, shell = True )
    cmd = "free -m | awk 'NR==2{printf \"Mem:%s/%sM %.2f%%\", $3,$2,$3*100/$2 }'"
    MemUsage = subprocess.check_output(cmd, shell = True )
    cmd = "df -h | awk '$NF==\"/\"{printf \"Disk:%d/%dGB %s\", $3,$2,$5}'"
    Disk = subprocess.check_output(cmd, shell = True )

    draw.text((x, top),       "eth0:" + str(get_ip_address('eth0')),  font=font, fill=255)
    draw.text((x, top+8),     "wlan0:" + str(get_ip_address('wlan0')), font=font, fill=255)
    draw.text((x, top+16),    str(MemUsage.decode('utf-8')),  font=font, fill=255)
    draw.text((x, top+25),    str(Disk.decode('utf-8')),  font=font, fill=255)

    # Display image
    disp.image(image)
    disp.display()
    time.sleep(1)

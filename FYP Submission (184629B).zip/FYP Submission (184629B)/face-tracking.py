from servoserial import ServoSerial
servo_device = ServoSerial()
from jetbot import Robot
robot = Robot()
import cv2
import traitlets
import PID
import numpy as np

HAAR_CASCADE_XML_FILE_FACE = "/usr/share/OpenCV/haarcascades/haarcascade_frontalface_default.xml"

GSTREAMER_PIPELINE = 'nvarguscamerasrc ! video/x-raw(memory:NVMM), width=3280, height=2464, format=(string)NV12, framerate=10/1 ! nvvidconv flip-method=0 ! video/x-raw, width=640, height=480, format=(string)BGRx ! videoconvert ! video/x-raw, format=(string)BGR ! appsink'

global face_x, face_y, face_w, face_h
face_x = face_y = face_w = face_h = 0
global target_valuex
target_valuex = 2100
global target_valuey
target_valuey = 2048

xservo_pid = PID.PositionalPID(1.9, 0.3, 0.35)
yservo_pid = PID.PositionalPID(1.5, 0.2, 0.3)

face_cascade = cv2.CascadeClassifier(HAAR_CASCADE_XML_FILE_FACE)

video_capture = cv2.VideoCapture(GSTREAMER_PIPELINE, cv2.CAP_GSTREAMER)
if video_capture.isOpened():
    cv2.namedWindow("Face Detection Window", cv2.WINDOW_AUTOSIZE)
    while True:
        return_key, image = video_capture.read()
        frame = cv2.resize(image, (300, 300))
        gray = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        faces = face_cascade.detectMultiScale(gray)
        if len(faces)>0:
           (face_x, face_y, face_w, face_h) = faces[0]
           # Mark the detected face
           cv2.rectangle(frame,(face_x,face_y),(face_x+face_h,face_y+face_w),(0,255,0),2)
           cv2.rectangle(frame,(face_x+10,face_y),(face_x+face_w-10,face_y+face_h+20),(0,255,0),2)
           #robot.left_motor.value = 0.4
           #robot.right_motor.value = 0.3
           robot.forward()
           # Proportion-Integration-Differentiation algorithm
           # Input X-axis direction parameter PID control input
           xservo_pid.SystemOutput = face_x+face_h/2
           xservo_pid.SetStepSignal(150)
           xservo_pid.SetInertiaTime(0.01, 0.006)
           target_valuex = int(2100 + xservo_pid.SystemOutput)
           if target_valuex >= 3400:
              target_valuex = 3400
           elif target_valuex <= 700:
              target_valuex = 700
           # Input Y axis direction parameter PID control input
           yservo_pid.SystemOutput = face_y+face_w/2
           yservo_pid.SetStepSignal(150)
           yservo_pid.SetInertiaTime(0.01, 0.006)
           target_valuey = int(2048+yservo_pid.SystemOutput)
           if target_valuey >= 3300:
              target_valuey = 3300
           elif target_valuey <= 1400:
              target_valuey = 1400
           # Rotate the gimbal to the PID adjustment position
           servo_device.Servo_serial_double_control(1, target_valuex, 2, target_valuey)
       
           cv2.imshow("Face Detection Window", frame)
           key = cv2.waitKey(30) & 0xff
           # Stop the program on the ESC key
           if key == 27:
              break

        else:
           robot.stop()

    video_capture.release()
    cv2.destroyAllWindows()
else:
    print("Cannot open Camera")

#Object Tracking
for i in range(len(boxes)):
            if i in indexes:
               x, y, w, h = boxes[i]
               label = str(classes[class_ids[i]])
               confidence = confidences[i]
               color = colors[class_ids[i]]
               cv2.rectangle(image, (x, y), (x + w, y + h), color, 2)
               cv2.rectangle(image, (x, y), (x + w, y + 30), color, -1)
               cv2.putText(image, label + " " + str(round(confidence, 2)), (x, y + 30), font, 3, (255,255,255), 3)
               # detection = 0
               if detection == 0:
                  robot.left_motor.value = 0.4
                  robot.right_motor.value = 0.3
                  servo_device.Servo_serial_control(1, 2100)
                  servo_device.Servo_serial_control(2, 2048)

#Collision Avoidance
for i in range(len(boxes)):
            if i in indexes:
               x, y, w, h = boxes[i]
               label = str(classes[class_ids[i]])
               confidence = confidences[i]
               color = colors[class_ids[i]]
               cv2.rectangle(image, (x, y), (x + w, y + h), color, 2)
               cv2.rectangle(image, (x, y), (x + w, y + 30), color, -1)
               cv2.putText(image, label + " " + str(round(confidence, 2)), (x, y + 30), font, 3, (255,255,255), 3)
               # detection = 0
               if detection == 0:
                  robot.left(0.3)
                  servo_device.Servo_serial_control(1, 2100)
                  servo_device.Servo_serial_control(2, 2048)
               else:
                  robot.left_motor.value = 0.4
                  robot.right_motor.value = 0.3

#consider the range of detection and the size of the object for detection
    

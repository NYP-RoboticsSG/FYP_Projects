from servoserial import ServoSerial
servo_device = ServoSerial()
import cv2
import traitlets
import PID
import numpy as np
from jetbot import Robot
robot = Robot()

GSTREAMER_PIPELINE = 'nvarguscamerasrc ! video/x-raw(memory:NVMM), width=3280, height=2464, format=(string)NV12, framerate=10/1 ! nvvidconv flip-method=0 ! video/x-raw, width=640, height=480, format=(string)BGRx ! videoconvert ! video/x-raw, format=(string)BGR ! appsink'

global color_x, color_y, color_radius
color_x = color_y = color_radius = 0
global target_valuex
target_valuex = 2100
global target_valuey
target_valuey = 2048

global color_lower
color_lower=np.array([156,43,46])
global color_upperv
color_upper = np.array([180, 255, 255])

xservo_pid = PID.PositionalPID(1.9, 0.3, 0.35)
yservo_pid = PID.PositionalPID(1.5, 0.2, 0.3)

#input
print("Jetbot is able to detect Red,Yellow,Blue,Green and Orange Colors")
color = str(input("What color do you want the robot to detect?: "))  

#output
print(color)

if color == "red":
   # red array data
   color_lower=np.array([0,43,46])
   color_upper = np.array([10, 255, 255])
   target_valuex = 2100
   target_valuey = 2048
   servo_device.Servo_serial_double_control(1, 2048, 2, 2048)
   video_capture = cv2.VideoCapture(GSTREAMER_PIPELINE, cv2.CAP_GSTREAMER)
   if video_capture.isOpened():
      cv2.namedWindow("Color Tracking Window", cv2.WINDOW_AUTOSIZE)
      while 1:
          return_key, image = video_capture.read()
          frame = cv2.resize(image, (300, 300))
          if return_key is True:
             hsv = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
          else:
             continue
          hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
          frame_=cv2.GaussianBlur(frame,(5,5),0)                    
          mask=cv2.inRange(hsv,color_lower,color_upper)  
          mask=cv2.erode(mask,None,iterations=2)
          mask=cv2.dilate(mask,None,iterations=2)
          mask=cv2.GaussianBlur(mask,(3,3),0)     
          cnts=cv2.findContours(mask.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[-2] 
          if len(cnts)>0:
             cnt = max (cnts,key=cv2.contourArea)
             (color_x,color_y),color_radius=cv2.minEnclosingCircle(cnt)
             if color_radius > 20:
                # Mark the detected color
                cv2.circle(frame,(int(color_x),int(color_y)),int(color_radius),(255,0,255),2)
                robot.left_motor.value = 0.4
                robot.right_motor.value = 0.4
                #robot.forward() 
                #Proportion-Integration-Differentiation
                xservo_pid.SystemOutput = color_x
                xservo_pid.SetStepSignal(150)
                xservo_pid.SetInertiaTime(0.01, 0.006)
                target_valuex = int(2100+xservo_pid.SystemOutput)
                if target_valuex >= 3400:
                   target_valuex = 3400
                elif target_valuex <= 700:
                   target_valuex = 700
                # Input Y axis direction parameter PID control input
                yservo_pid.SystemOutput = color_y
                yservo_pid.SetStepSignal(150)
                yservo_pid.SetInertiaTime(0.01, 0.006)
                target_valuey = int(2048+yservo_pid.SystemOutput)
                if target_valuey >= 3300:
                   target_valuey = 3300
                elif target_valuey <= 1400:
                   target_valuey = 1400
                # Rotate the gimbal to the PID adjustment position
                servo_device.Servo_serial_double_control( 1, target_valuex, 2, target_valuey)
             
                cv2.imshow("Color Tracking Window", frame)
                key = cv2.waitKey(30) & 0xff
                # Stop the program on the ESC key
                if key == 27:
                   break
          else:
             robot.stop()

      video_capture.release()
      cv2.destroyAllWindows()
   else:
       print("Cannot open Camera")

elif color == "yellow":
   # yellow array data
   color_lower=np.array([26,43,46])
   color_upper = np.array([34, 255, 255])
   target_valuex = 2100
   target_valuey = 2048
   servo_device.Servo_serial_double_control(1, 2048, 2, 2048)

   video_capture = cv2.VideoCapture(GSTREAMER_PIPELINE, cv2.CAP_GSTREAMER)
   if video_capture.isOpened():
      cv2.namedWindow("Color Tracking Window", cv2.WINDOW_AUTOSIZE)
      while 1:
          return_key, image = video_capture.read()
          frame = cv2.resize(image, (300, 300))
          if return_key is True:
             hsv = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
          else:
             continue
          hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
          frame_=cv2.GaussianBlur(frame,(5,5),0)                    
          mask=cv2.inRange(hsv,color_lower,color_upper)  
          mask=cv2.erode(mask,None,iterations=2)
          mask=cv2.dilate(mask,None,iterations=2)
          mask=cv2.GaussianBlur(mask,(3,3),0)     
          cnts=cv2.findContours(mask.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[-2] 
          if len(cnts)>0:
             cnt = max (cnts,key=cv2.contourArea)
             (color_x,color_y),color_radius=cv2.minEnclosingCircle(cnt)
             if color_radius > 20:
                # Mark the detected color
                cv2.circle(frame,(int(color_x),int(color_y)),int(color_radius),(255,0,255),2)
                robot.left_motor.value = 0.4
                robot.right_motor.value = 0.4
                #robot.forward() 
                #Proportion-Integration-Differentiation
                xservo_pid.SystemOutput = color_x
                xservo_pid.SetStepSignal(150)
                xservo_pid.SetInertiaTime(0.01, 0.006)
                target_valuex = int(2100+xservo_pid.SystemOutput)
                if target_valuex >= 3400:
                   target_valuex = 3400
                elif target_valuex <= 700:
                   target_valuex = 700
                # Input Y axis direction parameter PID control input
                yservo_pid.SystemOutput = color_y
                yservo_pid.SetStepSignal(150)
                yservo_pid.SetInertiaTime(0.01, 0.006)
                target_valuey = int(2048+yservo_pid.SystemOutput)
                if target_valuey >= 3300:
                   target_valuey = 3300
                elif target_valuey <= 1400:
                   target_valuey = 1400
                # Rotate the gimbal to the PID adjustment position
                servo_device.Servo_serial_double_control( 1, target_valuex, 2, target_valuey)
             
                cv2.imshow("Color Tracking Window", frame)
                key = cv2.waitKey(30) & 0xff
                # Stop the program on the ESC key
                if key == 27:
                   break

      video_capture.release()
      cv2.destroyAllWindows()
   else:
       print("Cannot open Camera")

elif color == "blue":
   # blue array data
   color_lower=np.array([100,43,46])
   color_upper = np.array([124, 255, 255])
   target_valuex = 2100
   target_valuey = 2048
   servo_device.Servo_serial_double_control(1, 2048, 2, 2048)
   video_capture = cv2.VideoCapture(GSTREAMER_PIPELINE, cv2.CAP_GSTREAMER)
   if video_capture.isOpened():
      cv2.namedWindow("Color Tracking Window", cv2.WINDOW_AUTOSIZE)
      while 1:
          return_key, image = video_capture.read()
          frame = cv2.resize(image, (300, 300))
          if return_key is True:
             hsv = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
          else:
             continue
          hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
          frame_=cv2.GaussianBlur(frame,(5,5),0)                    
          mask=cv2.inRange(hsv,color_lower,color_upper)  
          mask=cv2.erode(mask,None,iterations=2)
          mask=cv2.dilate(mask,None,iterations=2)
          mask=cv2.GaussianBlur(mask,(3,3),0)     
          cnts=cv2.findContours(mask.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[-2] 
          if len(cnts)>0:
             cnt = max (cnts,key=cv2.contourArea)
             (color_x,color_y),color_radius=cv2.minEnclosingCircle(cnt)
             if color_radius > 20:
                # Mark the detected color
                cv2.circle(frame,(int(color_x),int(color_y)),int(color_radius),(255,0,255),2)
                robot.left_motor.value = 0.4
                robot.right_motor.value = 0.4
                #robot.forward() 
                #Proportion-Integration-Differentiation
                xservo_pid.SystemOutput = color_x
                xservo_pid.SetStepSignal(150)
                xservo_pid.SetInertiaTime(0.01, 0.006)
                target_valuex = int(2100+xservo_pid.SystemOutput)
                if target_valuex >= 3400:
                   target_valuex = 3400
                elif target_valuex <= 700:
                   target_valuex = 700
                # Input Y axis direction parameter PID control input
                yservo_pid.SystemOutput = color_y
                yservo_pid.SetStepSignal(150)
                yservo_pid.SetInertiaTime(0.01, 0.006)
                target_valuey = int(2048+yservo_pid.SystemOutput)
                if target_valuey >= 3300:
                   target_valuey = 3300
                elif target_valuey <= 1400:
                   target_valuey = 1400
                # Rotate the gimbal to the PID adjustment position
                servo_device.Servo_serial_double_control( 1, target_valuex, 2, target_valuey)
             
                cv2.imshow("Color Tracking Window", frame)
                key = cv2.waitKey(30) & 0xff
                # Stop the program on the ESC key
                if key == 27:
                   break

      video_capture.release()
      cv2.destroyAllWindows()
   else:
       print("Cannot open Camera")

elif color == "green":
   # green array data
   color_lower=np.array([35,43,46])
   color_upper = np.array([77, 255, 255])
   target_valuex = 2100
   target_valuey = 2048
   servo_device.Servo_serial_double_control(1, 2048, 2, 2048)
   video_capture = cv2.VideoCapture(GSTREAMER_PIPELINE, cv2.CAP_GSTREAMER)
   if video_capture.isOpened():
      cv2.namedWindow("Color Tracking Window", cv2.WINDOW_AUTOSIZE)
      while 1:
          return_key, image = video_capture.read()
          frame = cv2.resize(image, (300, 300))
          if return_key is True:
             hsv = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
          else:
             continue
          hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
          frame_=cv2.GaussianBlur(frame,(5,5),0)                    
          mask=cv2.inRange(hsv,color_lower,color_upper)  
          mask=cv2.erode(mask,None,iterations=2)
          mask=cv2.dilate(mask,None,iterations=2)
          mask=cv2.GaussianBlur(mask,(3,3),0)     
          cnts=cv2.findContours(mask.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[-2] 
          if len(cnts)>0:
             cnt = max (cnts,key=cv2.contourArea)
             (color_x,color_y),color_radius=cv2.minEnclosingCircle(cnt)
             if color_radius > 20:
                # Mark the detected color
                cv2.circle(frame,(int(color_x),int(color_y)),int(color_radius),(255,0,255),2)
                robot.left_motor.value = 0.4
                robot.right_motor.value = 0.4
                #robot.forward() 
                #Proportion-Integration-Differentiation
                xservo_pid.SystemOutput = color_x
                xservo_pid.SetStepSignal(150)
                xservo_pid.SetInertiaTime(0.01, 0.006)
                target_valuex = int(2100+xservo_pid.SystemOutput)
                if target_valuex >= 3400:
                   target_valuex = 3400
                elif target_valuex <= 700:
                   target_valuex = 700
                # Input Y axis direction parameter PID control input
                yservo_pid.SystemOutput = color_y
                yservo_pid.SetStepSignal(150)
                yservo_pid.SetInertiaTime(0.01, 0.006)
                target_valuey = int(2048+yservo_pid.SystemOutput)
                if target_valuey >= 3300:
                   target_valuey = 3300
                elif target_valuey <= 1400:
                   target_valuey = 1400
                # Rotate the gimbal to the PID adjustment position
                servo_device.Servo_serial_double_control( 1, target_valuex, 2, target_valuey)
             
                cv2.imshow("Color Tracking Window", frame)
                key = cv2.waitKey(30) & 0xff
                # Stop the program on the ESC key
                if key == 27:
                   break

      video_capture.release()
      cv2.destroyAllWindows()
   else:
       print("Cannot open Camera")

elif color == "orange":
   # orange array data
   color_lower=np.array([11,43,46])
   color_upper = np.array([25, 255, 255])
   target_valuex = 2100
   target_valuey = 2048
   servo_device.Servo_serial_double_control(1, 2048, 2, 2048)
   video_capture = cv2.VideoCapture(GSTREAMER_PIPELINE, cv2.CAP_GSTREAMER)
   if video_capture.isOpened():
      cv2.namedWindow("Color Tracking Window", cv2.WINDOW_AUTOSIZE)
      while 1:
          return_key, image = video_capture.read()
          frame = cv2.resize(image, (300, 300))
          if return_key is True:
             hsv = cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
          else:
             continue
          hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
          frame_=cv2.GaussianBlur(frame,(5,5),0)                    
          mask=cv2.inRange(hsv,color_lower,color_upper)  
          mask=cv2.erode(mask,None,iterations=2)
          mask=cv2.dilate(mask,None,iterations=2)
          mask=cv2.GaussianBlur(mask,(3,3),0)     
          cnts=cv2.findContours(mask.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[-2] 
          if len(cnts)>0:
             cnt = max (cnts,key=cv2.contourArea)
             (color_x,color_y),color_radius=cv2.minEnclosingCircle(cnt)
             if color_radius > 20:
                # Mark the detected color
                cv2.circle(frame,(int(color_x),int(color_y)),int(color_radius),(255,0,255),2)
                robot.left_motor.value = 0.4
                robot.right_motor.value = 0.4
                #robot.forward()   
                #Proportion-Integration-Differentiation
                xservo_pid.SystemOutput = color_x
                xservo_pid.SetStepSignal(150)
                xservo_pid.SetInertiaTime(0.01, 0.006)
                target_valuex = int(2100+xservo_pid.SystemOutput)
                if target_valuex >= 3400:
                   target_valuex = 3400
                elif target_valuex <= 700:
                   target_valuex = 700
                # Input Y axis direction parameter PID control input
                yservo_pid.SystemOutput = color_y
                yservo_pid.SetStepSignal(150)
                yservo_pid.SetInertiaTime(0.01, 0.006)
                target_valuey = int(2048+yservo_pid.SystemOutput)
                if target_valuey >= 3300:
                   target_valuey = 3300
                elif target_valuey <= 1400:
                   target_valuey = 1400
                # Rotate the gimbal to the PID adjustment position
                servo_device.Servo_serial_double_control( 1, target_valuex, 2, target_valuey)
             
                cv2.imshow("Color Tracking Window", frame)
                key = cv2.waitKey(30) & 0xff
                # Stop the program on the ESC key
                if key == 27:
                   break

      video_capture.release()
      cv2.destroyAllWindows()
   else:
       print("Cannot open Camera")

else:
    print("Error")


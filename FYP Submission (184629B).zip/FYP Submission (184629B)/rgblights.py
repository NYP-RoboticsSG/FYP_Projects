from RGB_Lib import Programing_RGB
import time
RGB = Programing_RGB()

#one white
#RGB.Set_An_RGB(0, 0xFF, 0xFF, 0xFF)
#time.sleep(2)

#red
#RGB.Set_All_RGB(0xFF, 0x00, 0x00)
#time.sleep(2)

#green
#RGB.Set_All_RGB(0x00, 0xFF, 0x00)
#time.sleep(2)

#blue
RGB.Set_All_RGB(0x00, 0x00, 0xFF)
time.sleep(2)

RGB.OFF_ALL_RGB()

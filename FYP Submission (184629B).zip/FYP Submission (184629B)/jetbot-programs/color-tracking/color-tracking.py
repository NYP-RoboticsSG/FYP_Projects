from jetbot import Camera
from jetbot import bgr8_to_jpeg
import PID
camera = Camera.instance(width=720, height=720)

global color_x, color_y, color_radius
color_x = color_y = color_radius = 0
global target_valuex
target_valuex = 2100
global target_valuey
target_valuey = 2048

import numpy as np
global color_lower
color_lower=np.array([156,43,46])
global color_upperv
color_upper = np.array([180, 255, 255])

xservo_pid = PID.PositionalPID(1.9, 0.3, 0.35)
yservo_pid = PID.PositionalPID(1.5, 0.2, 0.3)

from servoserial import ServoSerial
servo_device = ServoSerial() 

import cv2
import traitlets
import ipywidgets.widgets as widgets
from IPython.display import display
color_image = widgets.Image(format='jpeg', width=300, height=300)
display(color_image)

# color recognition default array data
color_lower=np.array([156,43,46])
color_upper = np.array([180, 255, 255])
target_valuex = 2100
target_valuey = 2048
servo_device.Servo_serial_double_control(1, 2048, 2, 2048)

# red array data
color_lower=np.array([0,43,46])
color_upper = np.array([10, 255, 255])
target_valuex = 2100
target_valuey = 2048
servo_device.Servo_serial_double_control(1, 2048, 2, 2048)

# yellow array data
color_lower=np.array([26,43,46])
color_upper = np.array([34, 255, 255])
target_valuex = 2100
target_valuey = 2048
servo_device.Servo_serial_double_control(1, 2048, 2, 2048)

# blue array data
color_lower=np.array([100,43,46])
color_upper = np.array([124, 255, 255])
target_valuex = 2100
target_valuey = 2048
servo_device.Servo_serial_double_control(1, 2048, 2, 2048)

# green array data
color_lower=np.array([35,43,46])
color_upper = np.array([77, 255, 255])
target_valuex = 2100
target_valuey = 2048
servo_device.Servo_serial_double_control(1, 2048, 2, 2048)

# orange array data
color_lower=np.array([11,43,46])
color_upper = np.array([25, 255, 255])
target_valuex = 2100
target_valuey = 2048
servo_device.Servo_serial_double_control(1, 2048, 2, 2048)

while 1:
    frame = camera.value
    frame = cv2.resize(frame, (300, 300))
    frame_=cv2.GaussianBlur(frame,(5,5),0)                    
    hsv=cv2.cvtColor(frame,cv2.COLOR_BGR2HSV)
    mask=cv2.inRange(hsv,color_lower,color_upper)  
    mask=cv2.erode(mask,None,iterations=2)
    mask=cv2.dilate(mask,None,iterations=2)
    mask=cv2.GaussianBlur(mask,(3,3),0)     
    cnts=cv2.findContours(mask.copy(),cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)[-2] 
    if len(cnts)>0:
        cnt = max (cnts,key=cv2.contourArea)
        (color_x,color_y),color_radius=cv2.minEnclosingCircle(cnt)
        if color_radius > 10:
            # Mark the detected color
            cv2.circle(frame,(int(color_x),int(color_y)),int(color_radius),(255,0,255),2)  
            #Proportion-Integration-Differentiation
            xservo_pid.SystemOutput = color_x
            xservo_pid.SetStepSignal(150)
            xservo_pid.SetInertiaTime(0.01, 0.006)
            target_valuex = int(2100+xservo_pid.SystemOutput)
            # Input Y axis direction parameter PID control input
            yservo_pid.SystemOutput = color_y
            yservo_pid.SetStepSignal(150)
            yservo_pid.SetInertiaTime(0.01, 0.006)
            target_valuey = int(2048+yservo_pid.SystemOutput)
             # Rotate the gimbal to the PID adjustment position
            servo_device.Servo_serial_double_control( 1, target_valuex, 2, target_valuey)
     # Real-time return of image data for display
    color_image.value = bgr8_to_jpeg(frame)

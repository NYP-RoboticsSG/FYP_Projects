from servoserial import ServoSerial
import time
servo_device = ServoSerial()

# center position
servo_device.Servo_serial_control(1, 2100)
time.sleep(2)
servo_device.Servo_serial_control(2, 2048)

# rotate the servo to 1300
servo_device.Servo_serial_control(1, 1300)
time.sleep(2)
servo_device.Servo_serial_control(2, 1300)

# rotate the servo to 3600
servo_device.Servo_serial_control(1, 3600)
time.sleep(2)

servo_device.Servo_serial_control(2, 3600)

# center position
servo_device.Servo_serial_control(1, 2100)

from servoserial import ServoSerial
import time
servo_device = ServoSerial()

# center position
servo_device.Servo_serial_double_control(1, 2100, 2, 2048)
time.sleep(2)

# rotate the servo to 1300
servo_device.Servo_serial_double_control(1, 1300, 2, 1300)
time.sleep(2)

# rotate the servo to 3600
servo_device.Servo_serial_double_control(1, 3600, 2, 3600)
time.sleep(2)

# center position
servo_device.Servo_serial_double_control(1, 2100, 2, 2048)
time.sleep(2)


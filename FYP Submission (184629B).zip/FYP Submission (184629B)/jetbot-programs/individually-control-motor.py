robot.set_motors(0.5, 0.5)
time.sleep(1.0)
robot.stop()

robot.left_motor.value = 0.3
robot.right_motor.value = 0.6
time.sleep(1.0)
robot.left_motor.value = 0.0
robot.right_motor.value = 0.0

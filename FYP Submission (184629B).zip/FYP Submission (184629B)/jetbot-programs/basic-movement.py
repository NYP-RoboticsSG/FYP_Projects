from jetbot import Robot
robot = Robot()

robot.down(1)#PTZ rise

robot.up(1)#PTZ decline

robot.vertical_motors_stop()#stop PTZ

robot.forward(1)#Jetbot Robot car advance

robot.backward(1)#Jetbot Robot car back

robot.left(0.75)#Jetbot turn left

robot.right(0.75)#Jetbot turn right

robot.stop()#stop Jetbot

robot.set_bln(1)#Set Jetbot's onboard breathing lamp brightness to 1 (value range: 0 - 1.0)



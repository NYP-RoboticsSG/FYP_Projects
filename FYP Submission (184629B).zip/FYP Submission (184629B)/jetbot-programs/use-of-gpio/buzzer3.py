import RPi.GPIO as GPIO
import time

# Pin Definitions
BEEP_pin = 6 

# Pin Setup:
# Board pin-numbering scheme
GPIO.setmode(GPIO.BCM)
# set pin as an output pin with optional initial state of HIGH
GPIO.setup(BEEP_pin, GPIO.OUT, initial=GPIO.LOW)

GPIO.output(BEEP_pin, GPIO.HIGH)
time.sleep(0.1)
GPIO.output(BEEP_pin, GPIO.LOW)
time.sleep(0.2)
GPIO.output(BEEP_pin, GPIO.HIGH)
time.sleep(0.1)
GPIO.output(BEEP_pin, GPIO.LOW)
time.sleep(0.2)
GPIO.output(BEEP_pin, GPIO.HIGH)
time.sleep(0.1)
GPIO.output(BEEP_pin, GPIO.LOW)
time.sleep(0.2)

import RPi.GPIO as GPIO
import time

# Pin Definitions
BEEP_pin = 6 

def main():
    # Pin Setup:
    # Board pin-numbering scheme
    GPIO.setmode(GPIO.BCM)
    # set pin as an output pin with optional initial state of HIGH
    GPIO.setup(BEEP_pin, GPIO.OUT, initial=GPIO.HIGH)

    print("Starting demo now!")
    curr_value = GPIO.HIGH
    try:
        while True:
            time.sleep(1)
            # Toggle the output every second
            print("Outputting {} to pin {}".format(curr_value, BEEP_pin))
            GPIO.output(BEEP_pin, curr_value)
            curr_value ^= GPIO.HIGH
    finally:
        GPIO.cleanup()

if __name__ == '__main__':
    main()


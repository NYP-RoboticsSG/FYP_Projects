from jetbot import Robot
import time
robot = Robot()

import RPi.GPIO as GPIO
up_limit_pin = 17
down_limit_pin = 18
GPIO.setmode(GPIO.BCM)
GPIO.setup(up_limit_pin, GPIO.IN)
GPIO.setup(down_limit_pin, GPIO.IN)

import threading
global vertical_motors_action
vertical_motors_action = 0

def limit_detect():
    global vertical_motors_action
    while 1:
        if vertical_motors_action == 1:
            if GPIO.input(up_limit_pin) == 0:
                robot.vertical_motors_stop()
                vertical_motors_action = 0
                print('云台到顶')
        elif vertical_motors_action == 2:
            if GPIO.input(down_limit_pin) == 0:
                robot.vertical_motors_stop()
                vertical_motors_action = 0
                print('云台到底')
        time.sleep(0.5)

thread1 = threading.Thread(target=limit_detect)
# thread1.setDaemon(True)
thread1.start()

vertical_motors_action = 1
if(GPIO.input(up_limit_pin)):
    robot.up(1)
    print('cameraup')
else:
    print('Top')
    robot.vertical_motors_stop()
    vertical_motors_action = 0

vertical_motors_action = 2
if(GPIO.input(down_limit_pin)):
    robot.down(1)
    print('cameradown')
else:
    print('Bottom')
    robot.vertical_motors_stop()
    vertical_motors_action = 0

robot.vertical_motors_stop()
vertical_motors_action = 0
print('camerastop')

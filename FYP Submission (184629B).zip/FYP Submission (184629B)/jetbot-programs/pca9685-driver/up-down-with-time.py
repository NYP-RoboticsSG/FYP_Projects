from jetbot import Robot
import time
robot = Robot()

robot.up(1)
time.sleep(2.0)
robot.vertical_motors_stop()

robot.down(1)
time.sleep(2.0)
robot.vertical_motors_stop()

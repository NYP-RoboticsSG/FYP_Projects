from jetbot import Robot
import time
robot = Robot()

robot.left_motor.value = 0.8
robot.right_motor.value = 0.8

robot.left_motor.value = 0
robot.right_motor.value = 0
